select * from Employees
select * from Departments