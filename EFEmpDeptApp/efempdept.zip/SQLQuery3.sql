drop database EmployeeDepartmentContext;
drop table Departments